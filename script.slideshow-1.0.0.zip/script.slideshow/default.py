import xbmc


# entry point
if (__name__ == '__main__'):
    xbmc.executebuiltin('RecursiveSlideShow(/storage/pictures)')
